//
//  main.m
//  TraceRoute
//
//  Created by Mark Dalrymple on 8/19/10.
//  Copyright 2010 Borkware, LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
