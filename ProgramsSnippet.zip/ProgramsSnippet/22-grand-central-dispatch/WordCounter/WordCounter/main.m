//
//  main.m
//  WordCounter
//
//  Created by Mark Dalrymple on 5/5/11.
//  Copyright 2011 Borkware, LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
