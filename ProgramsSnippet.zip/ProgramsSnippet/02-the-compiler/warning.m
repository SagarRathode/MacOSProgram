// warning.m -- show generation of compiler warnings

// gcc -Wall -o warning warning.m

int main (int argc, char *argv) {
    int i;
} // main

