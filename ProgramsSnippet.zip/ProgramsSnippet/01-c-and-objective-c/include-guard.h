// include-guard.h -- making sure the contents of the header 
//                    are included only once.

#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

// Put the real header contents here.

#endif // INCLUDE_GUARD_H
