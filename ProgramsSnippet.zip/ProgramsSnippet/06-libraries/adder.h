// adder.h -- header file for the little adder functions we have

int add_0 (int number);
int add_1 (int number);
int add_2 (int number);
int add_3 (int number);
int add_4 (int number);

