// src1.c : a simple source file so we can fill a library

int add_1 (int number)
{
    return (number + 1);
} // add_1


