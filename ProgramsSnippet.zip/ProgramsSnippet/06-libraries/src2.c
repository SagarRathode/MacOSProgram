// src2.c : a simple source file so we can fill a library

int add_2 (int number)
{
    return (number + 2);
} // add_2


