// src0.c : a simple source file so we can fill a library

int add_0 (int number)
{
    return (number + 0);
} // add_0


