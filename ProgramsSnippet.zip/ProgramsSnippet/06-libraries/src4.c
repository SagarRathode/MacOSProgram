// src4.c : a simple source file so we can fill a library

int add_4 (int number)
{
    return (number + 4);
} // add_4


