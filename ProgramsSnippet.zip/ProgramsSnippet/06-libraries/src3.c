// src3.c : a simple source file so we can fill a library

int add_3 (int number)
{
    return (number + 3);
} // add_3


