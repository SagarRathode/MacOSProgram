gcc lstemperature.c -Wall -o lstemperature.o -framework IOKit -framework CoreFoundation
