#include <stdio.h>
   
void
hello(void)
{
    printf("Hello, Shared World!\n");
}
