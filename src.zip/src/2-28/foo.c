#include "foo.h"
#include <stdio.h>

int
main(void)
{
    printf("%d\n", FOO);
    return 0;
}
