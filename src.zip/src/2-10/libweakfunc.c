#include <stdio.h>
   
void
weakfunc(void)
{
    puts("I am a weak function.");
}
