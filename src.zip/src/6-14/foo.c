extern void bar(long long arg);
   
void
foo(void)
{
    bar((long long)1);
}
