extern void hello(void);
   
int
main(void)
{
    hello();
    return 0;
}
