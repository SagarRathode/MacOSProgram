#include <stdio.h>
   
void
my_start(void)
{
    printf("my_start\n");
}
   
void
hello(void)
{
    printf("Hello, World!\n");
}
