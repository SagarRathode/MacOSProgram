// customstack.c
   
#include <stdio.h>
   
int
main(void)
{
    int var; // a stack variable
    printf("&var = %p\n", &var);
    return 0;
}
