#include <stdio.h>
    
void 
hello(void)
{
    printf("Hello, World!\n");
} 
